/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: DefaultComponent 
	Configuration 	: Calculator_Block_Simulation
	Model Element	: DemoPkg
//!	Generated Date	: Wed, 19, Oct 2022  
	File Path	: DefaultComponent\Calculator_Block_Simulation\DemoPkg.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "DemoPkg.h"
//## auto_generated
#include "Calculator_Block.h"
//## package DemoPkg


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(DemoPkg, DemoPkg)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\Calculator_Block_Simulation\DemoPkg.cpp
*********************************************************************/
