/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: DefaultComponent 
	Configuration 	: Calculator_Block_Simulation
	Model Element	: DemoPkg
//!	Generated Date	: Wed, 19, Oct 2022  
	File Path	: DefaultComponent\Calculator_Block_Simulation\DemoPkg.h
*********************************************************************/

#ifndef DemoPkg_H
#define DemoPkg_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
class Calculator_Block;

//## package DemoPkg



#endif
/*********************************************************************
	File Path	: DefaultComponent\Calculator_Block_Simulation\DemoPkg.h
*********************************************************************/
