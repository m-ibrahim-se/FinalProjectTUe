/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: DefaultComponent 
	Configuration 	: Calculator_Block_Simulation
	Model Element	: Calculator_Block_Simulation
//!	Generated Date	: Wed, 19, Oct 2022  
	File Path	: DefaultComponent\Calculator_Block_Simulation\MainDefaultComponent.h
*********************************************************************/

#ifndef MainDefaultComponent_H
#define MainDefaultComponent_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
#endif
/*********************************************************************
	File Path	: DefaultComponent\Calculator_Block_Simulation\MainDefaultComponent.h
*********************************************************************/
