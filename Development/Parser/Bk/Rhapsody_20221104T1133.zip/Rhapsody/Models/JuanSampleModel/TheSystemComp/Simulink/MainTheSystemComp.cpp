/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystemComp 
	Configuration 	: Simulink
	Model Element	: Simulink
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystemComp\Simulink\MainTheSystemComp.cpp
*********************************************************************/

//## auto_generated
#include "MainTheSystemComp.h"
int main(int argc, char* argv[]) {
    int status = 0;
    if(OXF::initialize())
        {
            //#[ configuration TheSystemComp::Simulink 
            //#]
            OXF::start();
            status = 0;
        }
    else
        {
            status = 1;
        }
    return status;
}

/*********************************************************************
	File Path	: TheSystemComp\Simulink\MainTheSystemComp.cpp
*********************************************************************/
