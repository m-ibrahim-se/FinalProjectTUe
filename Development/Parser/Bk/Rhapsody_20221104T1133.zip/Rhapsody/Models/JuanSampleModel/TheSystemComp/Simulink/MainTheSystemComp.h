/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystemComp 
	Configuration 	: Simulink
	Model Element	: Simulink
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystemComp\Simulink\MainTheSystemComp.h
*********************************************************************/

#ifndef MainTheSystemComp_H
#define MainTheSystemComp_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
#endif
/*********************************************************************
	File Path	: TheSystemComp\Simulink\MainTheSystemComp.h
*********************************************************************/
