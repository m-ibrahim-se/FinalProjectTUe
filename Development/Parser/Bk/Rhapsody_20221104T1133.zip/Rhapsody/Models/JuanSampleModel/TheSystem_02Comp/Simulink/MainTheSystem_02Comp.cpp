/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: Simulink
	Model Element	: Simulink
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\Simulink\MainTheSystem_02Comp.cpp
*********************************************************************/

//## auto_generated
#include "MainTheSystem_02Comp.h"
int main(int argc, char* argv[]) {
    int status = 0;
    if(OXF::initialize())
        {
            //#[ configuration TheSystem_02Comp::Simulink 
            //#]
            OXF::start();
            status = 0;
        }
    else
        {
            status = 1;
        }
    return status;
}

/*********************************************************************
	File Path	: TheSystem_02Comp\Simulink\MainTheSystem_02Comp.cpp
*********************************************************************/
