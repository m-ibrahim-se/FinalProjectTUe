/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: Simulink
	Model Element	: Simulink
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\Simulink\MainTheSystem_02Comp.h
*********************************************************************/

#ifndef MainTheSystem_02Comp_H
#define MainTheSystem_02Comp_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
#endif
/*********************************************************************
	File Path	: TheSystem_02Comp\Simulink\MainTheSystem_02Comp.h
*********************************************************************/
