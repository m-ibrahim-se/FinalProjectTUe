/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: Simulink
	Model Element	: doubleFlowInterface
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\Simulink\doubleFlowInterface.cpp
*********************************************************************/

//## auto_generated
#include "doubleFlowInterface.h"
//#[ ignore
//## package FlowPortInterfaces

//## ignore
doubleFlowInterface::doubleFlowInterface() {
}

doubleFlowInterface::~doubleFlowInterface() {
}
//#]

/*********************************************************************
	File Path	: TheSystem_02Comp\Simulink\doubleFlowInterface.cpp
*********************************************************************/
