/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: SimulinkAnim
	Model Element	: FlowPortInterfaces
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\SimulinkAnim\FlowPortInterfaces.h
*********************************************************************/

#ifndef FlowPortInterfaces_H
#define FlowPortInterfaces_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
class doubleFlowInterface;

//## package FlowPortInterfaces



#endif
/*********************************************************************
	File Path	: TheSystem_02Comp\SimulinkAnim\FlowPortInterfaces.h
*********************************************************************/
