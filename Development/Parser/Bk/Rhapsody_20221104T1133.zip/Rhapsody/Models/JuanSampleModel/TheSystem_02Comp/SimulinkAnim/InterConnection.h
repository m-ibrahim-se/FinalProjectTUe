/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: SimulinkAnim
	Model Element	: InterConnection
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\SimulinkAnim\InterConnection.h
*********************************************************************/

#ifndef InterConnection_H
#define InterConnection_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
class Generator_02;

//## auto_generated
class SFunctionBlockTheSystem_02;

//## package InterConnection


//## auto_generated
void InterConnection_initRelations();

#endif
/*********************************************************************
	File Path	: TheSystem_02Comp\SimulinkAnim\InterConnection.h
*********************************************************************/
