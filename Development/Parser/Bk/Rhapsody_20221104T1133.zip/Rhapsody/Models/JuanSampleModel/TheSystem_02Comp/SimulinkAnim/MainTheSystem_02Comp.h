/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20204920
	Component	: TheSystem_02Comp 
	Configuration 	: SimulinkAnim
	Model Element	: SimulinkAnim
//!	Generated Date	: Thu, 3, Nov 2022  
	File Path	: TheSystem_02Comp\SimulinkAnim\MainTheSystem_02Comp.h
*********************************************************************/

#ifndef MainTheSystem_02Comp_H
#define MainTheSystem_02Comp_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
class TheSystem_02Comp {
    ////    Constructors and destructors    ////
    
public :

    TheSystem_02Comp();
};

#endif
/*********************************************************************
	File Path	: TheSystem_02Comp\SimulinkAnim\MainTheSystem_02Comp.h
*********************************************************************/
