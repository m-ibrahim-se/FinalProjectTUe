We can only run python file to parse and load the data. MATLAB is not necessary opened on that time.
Run the python script as "python -m 'fileName[without .py]'"