mails_path = "emails/"
gitlab_path = "gitlab/"
slack_path = "slack/"
magicdraw_path = "magicdraw/"
magicdraw_file = "graphschema.mdxml"
gitlab_group_keyword = 'UNSW'
pdf_path = "docs/"