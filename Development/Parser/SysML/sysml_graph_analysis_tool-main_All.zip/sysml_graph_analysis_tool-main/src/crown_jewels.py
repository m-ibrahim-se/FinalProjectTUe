***REMOVED***
***REMOVED***
***REMOVED***
***REMOVED***
neo4juri      = 'bolt://localhost:7687'
neo4jusername = 'neo4j'
neo4jpassword = 'asdf'
