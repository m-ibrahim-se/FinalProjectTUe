# files that should be here before the retrieve_emails script is executed:

all mails in outlook's `.msg` format

# files that should be here after the code retrieve_emails.py script was executed:

- `emails_list.json`
