# the magicdraw .mdxml or .xml file has to be put here in order to be inserted into Neo4j
 
# this directory also includes all json files containing the magicdraw model data after the python script was executed