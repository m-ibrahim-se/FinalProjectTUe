# files that should be here after the code retrieve_from_gitlab.py script was executed:

- `channels.json` file with all channels of the slack workspace
- `files.json` list of all files and their metadata of the slack workspace
- `messages.json` list of all messages of the slack workspace
- `threads.json` list of all threads to the messages of the slack workspace
- `users.json` list of all users of the slack workspace
